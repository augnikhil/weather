export const black1 = "rgb(17, 16, 16)";
export const black = "black";
export const white = "white";
export const bg1 = "linear-gradient(45deg,rgba(45, 47, 51, 0.8) 17%,rgba(36, 86, 118, 0.7) 50%,rgba(45, 47, 51, 0.7) 80%)";
export const bg2 = "linear-gradient(45deg,rgba(45, 47, 51, 1) 17%,rgba(36, 86, 118, 1) 50%,rgba(45, 47, 51, 1) 80%)";
export const bg = "linear-gradient(-45deg,rgba(45, 47, 51, 0.8) 17%,rgba(36, 86, 118, 0.7) 50%,rgba(45, 47, 51, 0.7) 80%)";
export const gray = "gray"

